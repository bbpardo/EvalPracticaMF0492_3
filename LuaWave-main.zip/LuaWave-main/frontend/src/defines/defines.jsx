const urls = [
    "http://localhost:4000/api/v0.0/articles/surf/con",
    "http://localhost:4000/api/v0.0/articles/surf/sin",
    "http://localhost:4000/api/v0.0/articles/skate/con",
    "http://localhost:4000/api/v0.0/articles/skate/sin",
    "http://localhost:4000/api/v0.0/order"

]

export {urls}