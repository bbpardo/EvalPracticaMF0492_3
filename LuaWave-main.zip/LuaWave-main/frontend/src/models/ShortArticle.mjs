export class ShortArticle{
    constructor({Articles_id, Quantity}){
        this.Articles_id = Articles_id;
        this.Quantity= Quantity
    }
}